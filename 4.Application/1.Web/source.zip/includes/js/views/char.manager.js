$(document).ready(function() {
	/*
	 * VECTOR MAP
	 */

	data_array = {
		"US" : 4977,
		"AU" : 4873,
		"IN" : 3671,
		"BR" : 2476,
		"TR" : 1476,
		"CN" : 146,
		"CA" : 134,
		"BD" : 100
	};

	$('#vector-map').vectorMap({
		map : 'world_mill_en',
		backgroundColor : '#fff',
		regionStyle : {
			initial : {
				fill : '#c4c4c4'
			},
			hover : {
				"fill-opacity" : 1
			}
		},
		series : {
			regions : [{
				values : data_array,
				scale : ['#85a8b6', '#4d7686'],
				normalizeFunction : 'polynomial'
			}]
		},
		onRegionLabelShow : function(e, el, code) {
			if ( typeof data_array[code] == 'undefined') {
				e.preventDefault();
			} else {
				var countrylbl = data_array[code];
				el.html(el.html() + ': ' + countrylbl + ' visits');
			}
		}
	});

	/* chart colors default */
	var $chrt_border_color = "#efefef";
	var $chrt_grid_color = "#DDD"
	var $chrt_main = "#E24913";
	/* red       */
	var $chrt_second = "#6595b4";
	/* blue      */
	var $chrt_third = "#FF9F01";
	/* orange    */
	var $chrt_fourth = "#7e9d3a";
	/* green     */
	var $chrt_fifth = "#BD362F";
	/* dark red  */
	var $chrt_mono = "#000";


	if ($("#bar-chart").length) {

		var data1 = [];
		for (var i = 0; i <= 5; i += 1)
			data1.push([i, parseInt(Math.random() * 500 + 100)]);

		var data2 = [];
		for (var i = 0; i <= 5; i += 1)
			data2.push([i, parseInt(Math.random() * 200)]);


		var ds = new Array();

		ds.push({
			data : data1
			// ,
			// bars : {
			// 	show : true,
			// 	barWidth : 0.2,
			// 	order : 1,
			// }
		});
		ds.push({
			data : data2
			// ,
			// bars : {
			// 	show : true,
			// 	barWidth : 0.2,
			// 	order : 2
			// }
		});

		
		var xticks = [[0, "AXA International Ltd."], [1, "KEEN HING INDUSTRIES LIMITED CO."], [2, "DONG NAM CO., LTD."], [3, "HONG IK VINA CO. LTD."], [4, "DONGJIN TABLEWARE"], [5, "LEADERS INDUSTRIAL LIMITED LITONG"]];
		var yticks = [0,100,200,300,400,500,600,700,800,900];

		//Display graph
		$.plot($("#bar-chart"), ds, {
			series: {
			    stack: true,
			    bars: {
			        show: true
			    }
			},
			 bars: {
			 	align: "center",
		        // lineWidth: 1,
		        barWidth: 0.2,
		        // horizontal: true
		    },
			colors : ["#33cc33", "#cc0000", "#666", "#BBB"],
			grid : {
				show : true,
				hoverable : true,
				clickable : true,
				tickColor : $chrt_border_color,
				borderWidth : 0,
				borderColor : $chrt_border_color,
			},
			legend : true,
			tooltip : true,
			tooltipOpts : {
				content : "<b>%x</b> = <span>%y</span>",
				defaultTheme : false
			},
			xaxis:{
				ticks: xticks
			},
			yaxis: {
				axisLabel: "Value x 1000",
				axisLabelUseCanvas: true,
			    axisLabelFontSizePixels: 12,
			    axisLabelFontFamily: 'Verdana, Arial',
			    axisLabelPadding: 3,
				ticks: yticks,
				tickFormatter: function (v, axis) {
	        		return v + " $";
				}
			}
		});

	}

	if ($("#bar-chart-inspection-lot").length) {

		var data1 = [];
		for (var i = 0; i <= 5; i += 1)
			data1.push([i, parseInt(Math.random() * 500 + 100)]);

		var data2 = [];
		for (var i = 0; i <= 5; i += 1)
			data2.push([i, parseInt(Math.random() * 200)]);


		var ds = new Array();

		ds.push({
			data : data1
			// ,
			// bars : {
			// 	show : true,
			// 	barWidth : 0.2,
			// 	order : 1,
			// }
		});
		ds.push({
			data : data2
			// ,
			// bars : {
			// 	show : true,
			// 	barWidth : 0.2,
			// 	order : 2
			// }
		});

		
		var xticks = [[0, "AXA International Ltd."], [1, "KEEN HING INDUSTRIES LIMITED CO."], [2, "DONG NAM CO., LTD."], [3, "HONG IK VINA CO. LTD."], [4, "DONGJIN TABLEWARE"], [5, "LEADERS INDUSTRIAL LIMITED LITONG"]];
		var yticks = [0,100,200,300,400,500,600,700,800,900];

		//Display graph
		$.plot($("#bar-chart-inspection-lot"), ds, {
			series: {
			    stack: true,
			    bars: {
			        show: true
			    }
			},
			 bars: {
			 	align: "center",
		        // lineWidth: 1,
		        barWidth: 0.2,
		        // horizontal: true
		    },
			colors : ["#33cc33", "#cc0000", "#666", "#BBB"],
			grid : {
				show : true,
				hoverable : true,
				clickable : true,
				tickColor : $chrt_border_color,
				borderWidth : 0,
				borderColor : $chrt_border_color,
			},
			legend : true,
			tooltip : true,
			tooltipOpts : {
				content : "<b>%x</b> = <span>%y</span>",
				defaultTheme : false
			},
			xaxis: {ticks: xticks},
			yaxis: {ticks: yticks}
		});

	}

	if ($("#line-chart-inspection-lot").length) {

		var data1 = [];
		for (var i = 0; i <= 5; i += 1)
			data1.push([i, parseInt(Math.random() * 100)]);

		var data2 = [];
		for (var i = 0; i <= 5; i += 1)
			data2.push([i, parseInt(Math.random() * 100)]);


		var ds = new Array();

		ds.push({
			label : "Rejected lots",
			data : data1
			// ,
			// bars : {
			// 	show : true,
			// 	barWidth : 0.2,
			// 	order : 1,
			// }
		});
		ds.push({
			label : "Rejected values",
			data : data2
			// ,
			// bars : {
			// 	show : true,
			// 	barWidth : 0.2,
			// 	order : 2
			// }
		});

		
		var xticks = [[0, "AXA International Ltd."], [1, "KEEN HING INDUSTRIES LIMITED CO."], [2, "DONG NAM CO., LTD."], [3, "HONG IK VINA CO. LTD."], [4, "DONGJIN TABLEWARE"], [5, "LEADERS INDUSTRIAL LIMITED LITONG"]];
		var yticks = [0,10,20,30,40,50,60,70,80,90,100];

		//Display graph
		$.plot($("#line-chart-inspection-lot"), ds, {
			series: {
			    // stack: true,
			    lines : {
					show : true,
					lineWidth : 1,
					fill : true,
					fillColor : {
						colors : [{
							opacity : 0.1
						}, {
							opacity : 0.15
						}]
					}
				},
				points : {
					show : true
				}
			},
			bars: {
			 	align: "center",
		        // lineWidth: 1,
		        barWidth: 0.2,
		        // horizontal: true
		    },
			colors : ["#33cc33", "#cc0000", "#666", "#BBB"],
			grid : {
				show : true,
				hoverable : true,
				clickable : true,
				tickColor : $chrt_border_color,
				borderWidth : 0,
				borderColor : $chrt_border_color,
			},
			legend: {
                noColumns: 0,
                labelBoxBorderColor: "#000000",
                position: "ne"
            },
			tooltip : true,
			tooltipOpts : {
				content : "<b>%x</b> = <span>%y</span>",
				defaultTheme : false
			},
			xaxis: {ticks: xticks},
			yaxis: {
				ticks: yticks,
				tickFormatter: function (v, axis) {
	        		return v + " %";
				}
			}
		});
		$("#line-chart-inspection-lot div.legend table").css({ top: "-4px"});

	}

	if ($("#line-chart-inspection-time").length) {

		var data1 = [];
		for (var i = 0; i <= 11; i += 1)
			data1.push([i, parseInt(Math.random() * 40)]);

		var data2 = [];
		for (var i = 0; i <= 11; i += 1)
			data2.push([i, parseInt(Math.random() * 20)]);

		var data3 = [];
		for (var i = 0; i <= 11; i += 1)
			data3.push([i, parseInt(Math.random() * 10)]);

		var data4 = [];
		for (var i = 0; i <= 11; i += 1)
			data4.push([i, parseInt(Math.random() * 30)]);

		var data5 = [];
		for (var i = 0; i <= 11; i += 1)
			data5.push([i, parseInt(Math.random() * 30 + 30)]);



		var ds = new Array();


		var dataset = [
		    { label: "AXA International Ltd.", data: data1 },
		    { label: "KEEN HING INDUSTRIES LIMITED CO.", data: data2 },
		    { label: "DONG NAM CO., LTD.", data: data3 },
		    { label: "HONG IK VINA CO. LTD.", data: data4 },
		    { label: "DONGJIN TABLEWARE", data: data5 }
		];

		
		var xticks = [[0, "1/2015"], [1, "2/2015"], [2, "3/2015"], [3, "4/2015"], [4,"5/2015"], [5, "6/2015"], [6, "7/2015"], [7, "8/2015"], [8, "9/2015"], [9, "10/2015"], [10, "11/2015"], [11, "12/2015"]];
		var yticks = [0,10,20,30,40,50,60,70,80,90,100];

		//Display graph
		$.plot($("#line-chart-inspection-time"), dataset, {
			series: {
			    // stack: true,
			    lines : {
					show : true,
					lineWidth : 5,
					fill : false,
					fillColor : {
						colors : [{
							opacity : 0.1
						}, {
							opacity : 0.15
						}]
					}
				},
				points : {
					show : true
				}
			},
			
			colors : ["#33cc33", "#cc0000", "#666", "#BBB"],
			grid : {
				show : true,
				hoverable : true,
				clickable : true,
				tickColor : $chrt_border_color,
				borderWidth : 0,
				borderColor : $chrt_border_color,
			},
			  legend: {
                noColumns: 0,
                labelBoxBorderColor: "#000000",
                position: "ne"
            },
			// legend : true,
			// legend: {
			//     show: true,  
			//     //show or hide legend
			//     // labelFormatter: null or (fn: string, series object -> string)
			//     //formatting your legend label by using custom functions
			//     labelBoxBorderColor: "red",
			//     //label border color
			//     // noColumns: 5,
			//     //number of legend columns
			//     position: "e"   ,
			//     //legend position (north east, north west, south east, south west)
			//     // margin: number of pixels or [x margin, y margin]
			//     margin:[10,10],
			//     backgroundColor: "white"
			//     // backgroundOpacity: number between 0 and 1
			//     // container: null or jQuery object/DOM element/jQuery expression        
			// },
			tooltip : true,
			tooltipOpts : {
				content : "<b>%x</b> = <span>%y</span>",
				defaultTheme : false
			},
			xaxis: {
				ticks: xticks
			},
			yaxis: {
				ticks: yticks,
				tickFormatter: function (v, axis) {
	        		return v + " %";
				}
			}
		});
		$("#line-chart-inspection-time div.legend table").css({ top: "-4px"});

	}

	if ($("#bar-chart-shipping-information").length) {

		var data1 = [];
		var data2 = [];
		var data3 = [];

		for (var i = 0; i <= 11; i += 1){
			var temp1 = parseInt(Math.random() * 20 + 50) ;
			var temp2 = parseInt(Math.random() * 20);
			var temp3 = 100 - (temp1 + temp2);

			data1.push([i, temp1]);
			data2.push([i, temp2]);
			data3.push([i, temp3]);
		}
			

		
		// for (var i = 0; i <= 11; i += 1)
		// 	data2.push([i, parseInt(Math.random() * 20)]);

		
		// for (var i = 0; i <= 11; i += 1)
		// 	data3.push([i, parseInt(Math.random() * 20)]);

		var data4 = [];
		for (var i = 0; i <= 11; i += 1)
			data4.push([i, parseInt(Math.random() * 30)]);

		var data5 = [];
		for (var i = 0; i <= 11; i += 1)
			data5.push([i, parseInt(Math.random() * 30 + 30)]);



		var ds = new Array();


		var dataset = [
		    { label: "On time shipping", data: data1 },
		    { label: "Early shipping", data: data2 },
		    { label: "Late shipping", data: data3 }
		];

		
		var xticks = [[0, "1/2015"], [1, "2/2015"], [2, "3/2015"], [3, "4/2015"], [4,"5/2015"], [5, "6/2015"], [6, "7/2015"], [7, "8/2015"], [8, "9/2015"], [9, "10/2015"], [10, "11/2015"], [11, "12/2015"]];
		var yticks = [0,10,20,30,40,50,60,70,80,90,100];

		//Display graph
		$.plot($("#bar-chart-shipping-information"), dataset, {
			series: {
			    stack: true,
			    bars: {
			        show: true,
			        align: "center",
		        	barWidth: 0.2
			    }
			},
			
			colors : ["#33cc33", "#cc0000", "#666", "#BBB"],
			grid : {
				show : true,
				hoverable : true,
				clickable : true,
				tickColor : $chrt_border_color,
				borderWidth : 0,
				borderColor : $chrt_border_color,
			},
			  legend: {
                noColumns: 0,
                labelBoxBorderColor: "#000000",
                position: "ne"
            },
			tooltip : true,
			tooltipOpts : {
				content : "<b>%x</b> = <span>%y</span>",
				defaultTheme : false
			},
			xaxis: {
				ticks: xticks
			},
			yaxis: {
				ticks: yticks,
				tickFormatter: function (v, axis) {
	        		return v + " %";
				}
			}
		});
		$("#bar-chart-shipping-information div.legend table").css({ top: "-4px"});

	}


	if ($("#line-chart-order-information").length) {

		var data1 = [];
		

		for (var i = 0; i <= 11; i += 1){
			var temp1 = parseInt(Math.random() * 400 + 200) ;
			data1.push([i, temp1]);
	
		}
			
		var dataset = [
		    { label: "", data: data1 }
		  
		   
		];

		
		var xticks = [[0, "1/2015"], [1, "2/2015"], [2, "3/2015"], [3, "4/2015"], [4,"5/2015"], [5, "6/2015"], [6, "7/2015"], [7, "8/2015"], [8, "9/2015"], [9, "10/2015"], [10, "11/2015"], [11, "12/2015"]];
		var yticks = [0,100,200,300,400,500,600,700,800,900,1000];

		//Display graph
		$.plot($("#line-chart-order-information"), dataset, {
			series: {
			    lines : {
					show : true,
					lineWidth : 1,
					fill : true,
					fillColor : {
						colors : [{
							opacity : 0.1
						}, {
							opacity : 0.15
						}]
					}
				},
				points : {
					show : true
				}
			},
			
			colors : ["#33cc33", "#cc0000", "#666", "#BBB"],
			grid : {
				show : true,
				hoverable : true,
				clickable : true,
				tickColor : $chrt_border_color,
				borderWidth : 0,
				borderColor : $chrt_border_color,
			},
			  legend: {
                noColumns: 0,
                labelBoxBorderColor: "#000000",
                position: "ne"
            },
		 
			tooltip : true,
			tooltipOpts : {
				content : "<b>%x</b> = <span>%y</span>",
				defaultTheme : false
			},
			xaxis: {
				ticks: xticks
			},
			yaxis: {
				axisLabel: "Value x 1000",
				ticks: yticks,
				tickFormatter: function (v, axis) {
	        		return v + " $";
				}
			}
		});
		$("#line-chart-order-information div.legend table").css({ top: "-4px"});

	}

	if ($("#line-chart-order-information-quantity").length) {

		var data1 = [];
		

		for (var i = 0; i <= 11; i += 1){
			var temp1 = parseInt(Math.random() * 400 + 200) ;
			data1.push([i, temp1]);
		}
			
		var dataset = [
		    { label: "", data: data1 }
		];

		
		var xticks = [[0, "1/2015"], [1, "2/2015"], [2, "3/2015"], [3, "4/2015"], [4,"5/2015"], [5, "6/2015"], [6, "7/2015"], [7, "8/2015"], [8, "9/2015"], [9, "10/2015"], [10, "11/2015"], [11, "12/2015"]];
		var yticks = [0,100,200,300,400,500,600,700,800,900];

		//Display graph
		$.plot($("#line-chart-order-information-quantity"), dataset, {
			series: {
			    lines : {
					show : true,
					lineWidth : 1,
					fill : true,
					fillColor : {
						colors : [{
							opacity : 0.1
						}, {
							opacity : 0.15
						}]
					}
				},
				points : {
					show : true
				}
			},
			
			colors : ["#33cc33", "#cc0000", "#666", "#BBB"],
			grid : {
				show : true,
				hoverable : true,
				clickable : true,
				tickColor : $chrt_border_color,
				borderWidth : 0,
				borderColor : $chrt_border_color,
			},
			  legend: {
                noColumns: 0,
                labelBoxBorderColor: "#000000",
                position: "ne"
            },
		 
			tooltip : true,
			tooltipOpts : {
				content : "<b>%x</b> = <span>%y</span>",
				defaultTheme : false
			},
			xaxis: {
				ticks: xticks
			},
			yaxis: {
				ticks: yticks,
				tickFormatter: function (v, axis) {
	        		return v + "";
				}
			}
		});
		$("#line-chart-order-information-quantity div.legend table").css({ top: "-4px"});

	}

	 

	if ($('#pie-chart').length) {

		var data_pie = [];
		var series = Math.floor(Math.random() * 10) + 1;
		data_pie[1] = {
			label : "On time shipping",
			data  : 74
			}
		data_pie[0] = {
			label : "Late shipping",
			data  : 15
			}
		data_pie[2] = {
			label : "Early shipping",
			data  : 11
			}

		$.plot($("#pie-chart"), data_pie, {
			series : {
				pie : {
					show : true,
					// innerRadius : 0.5,
					radius : 1,
					label : {
						show : true,
						radius : 2 / 3,
						formatter : function(label, series) {
							return '<div style="font-size:11px;text-align:center;padding:4px;color:white;">' + label + '<br/>' + Math.round(series.percent) + '%</div>';
						},
						threshold : 0.1
					}
				}
			},
			legend : {
				show : true,
				noColumns : 1, // number of colums in legend table
				labelFormatter : null, // fn: string -> string
				labelBoxBorderColor : "#000", // border color for the little label boxes
				container : null, // container (as jQuery object) to put legend in, null means default on top of graph
				position : "ne", // position of default legend container within plot
				margin : [5, 10], // distance from grid edge to default legend container within plot
				backgroundColor : "#efefef", // null means auto-detect
				backgroundOpacity : 1 // set to 0 to avoid background
			},
			grid : {
				hoverable : true,
				clickable : true
			},
		});

	}
})