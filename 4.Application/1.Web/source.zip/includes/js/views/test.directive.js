(function(){
  var app = angular.module('BasicData', ['datatables']);
  app.controller("ShowSchedule",function($scope,$http,DTOptionsBuilder,DTColumnBuilder,$filter,$locale){
    // $scope.locale = $locale;
    console.log($locale);
    $scope.suppliers = [];
    $scope.suppliers  = [];
    $scope.currentDate = new Date();
    $scope.frmDate = $filter('date')($scope.currentDate.getCurrentWeek().start, "dd MMM yyyy");
    $scope.toDate = $filter('date')($scope.currentDate.getCurrentWeek().end, "dd MMM yyyy");
    $scope.slSupplier = 0;
    $scope.slDurationTime = "cw";
    $scope.dtInstance = {};
    $scope.durationTimes = [{key : 'cw', value : 'This week'},{key:'nw',value: 'Next week'},{key:'cm',value: 'This month'},{key:'nm',value: 'Next month'},{key:'cq',value: 'This quarter'}];

    var url = '/index.cfm/test.getListSchedule';
    $http.get("/index.cfm/utils.getListSupplier/").success(function(dataResponse){
      $scope.suppliers = dataResponse;
    });

    $scope.searchSchedule = function(){
      $scope.dtOptions = DTOptionsBuilder
                                .fromSource(url + '?frmDate=' + $scope.frmDate + '&toDate=' + $scope.toDate + '&slSupplier=' + $scope.slSupplier)
                                ;
      $scope.dtInstance.reloadData();
    }
    $scope.dtOptions = DTOptionsBuilder
                                .fromSource(url + '?frmDate=' + $scope.frmDate + '&toDate=' + $scope.toDate + '&slSupplier=' + $scope.slSupplier)
                                ;
    $scope.dtColumns = [
        DTColumnBuilder.newColumn("order_no","Order No"),
        DTColumnBuilder.newColumn("position_no","Position No"),
        DTColumnBuilder.newColumn("abno","AB No"),
        DTColumnBuilder.newColumn("pattern_itemid","Pattern Item No"),
        DTColumnBuilder.newColumn("product_name","Product Name"),
        DTColumnBuilder.newColumn("segment","Segment"),
        DTColumnBuilder.newColumn("shipped_quantity","Shipped Quantity"),
        DTColumnBuilder.newColumn("supplier","Supplier"),
        DTColumnBuilder.newColumn("inspection_planDate","Schedule date").renderWith(function(data) {
            return $filter('date')(new Date(data), "dd MMM yyyy");
        })
    ];

    $scope.selectDuration = function(){
      switch($scope.slDurationTime) {
        case 'cw': date_range = $scope.currentDate.getCurrentWeek(); break;
        case 'cm':
          date_range = {
            start: new Date($scope.currentDate.getFullYear(), $scope.currentDate.getMonth(), 1),
            end: Date.getLastMonthDate()
          };
          break;
        case 'cq': date_range = Date.getQuarterRange($scope.currentDate.getCurrentQuarter()); break;
        case 'nw':
          var next = new Date();
          next.setDate($scope.currentDate.getDate() + 7);
          date_range = next.getCurrentWeek();
          break;
        case 'nm':
          date_range = {
            start: new Date($scope.currentDate.getFullYear(), $scope.currentDate.getMonth() + 1, 1),
            end: Date.getLastMonthDate($scope.currentDate.getMonth() + 1)
          };
          break;
      };
      $scope.frmDate = $filter('date')(date_range.start, "dd MMM yyyy");
      $scope.toDate = $filter('date')(date_range.end, "dd MMM yyyy");
    }

  });
  app.directive('supplierList',function(){
    return{
        restrict: 'EA',
        templateUrl: '/html/supplier.html'
    };
  });


})();


