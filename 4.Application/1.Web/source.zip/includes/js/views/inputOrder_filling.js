$('input[name=order_date]').val(new Date().toFormat(date_shown));

var cache = { customer:{}, supplier:{}, item:{} };

$(document).on('keypress', '#modalWarn', function (e) { 
	if (e.charCode == 13)	
		$('#modalWarn').modal('hide');
});

// inputting order general information

$(document).on('change', 'input[name=order_no]', function(e){
	var order_text = "Order Position Information";
	if ( $(this).val() != '' ) order_text += ' :: Order No.'+$(this).val();
	$('#order_position')[0].innerText = order_text;
});

$('#cus_name').autocomplete({
	minLength: 2,
	source: function(request, response) {
		var term = request.term.trim();
		// console.log(term.length);
		if (term in cache.customer) {
			response(cache.customer[term]);
			return;
		};
		$.ajax({
			url: '/index.cfm/order.companyInfo',
			data: {name_term: term , kind: 3},
			dataType: 'JSON',
			success: function(data) {
				var res = data.map(function( item ) {
					return {
						value: item.name.trim(), gid: item.gildemeisterid.trim(), id: item.companyid,
						address: item.address.trim()+' - '+item.country.trim(),
						mail: item.mail.trim(), phone: item.phone.trim(), fax: item.fax.trim()
					}; });
				cache.customer[term] = res;
				response(res);
			}
		});
	},
	focus: function(evnt,ui) {
		$('#cus_name').val(ui.item.value);
	},
	select: function(evnt, ui) {
		$('#cus_name').attr('gid', ui.item.gid);
		$('#cus_number').val(ui.item.gid).attr('companyid',ui.item.id);
		$('#cus_address').text(ui.item.address);
		$('#cus_mail').val(ui.item.mail);
		$('#cus_phone').val(ui.item.phone);
		$('#cus_fax').val(ui.item.fax);
	}
});

$(document).on('focusout', '#cus_name', function (e) {
	$('#cus_number').trigger('change');
});

$(document).on('change', '#cus_number', function (e) {
	$('#select-purchaser').empty().append('<option value="0">Select a person</option>');
	$('#select-planner').empty().append('<option value="0">Select a person</option>');
	if ($(this).val() != $('#cus_name').attr('gid')) {
		$('#cus_name').val('').attr('gid','');
		$(this).val('');
		$('#cus_address').text('');
		$('#cus_person').val('');
		$('#cus_mail').val('');
		$('#cus_phone').val('');
		$('#cus_fax').val('');
		return;
	};
	// console.log('member fetching...');
	$.ajax({
		type: "get", 
		url: "/index.cfm/order.companyMember",
		data: {gid: $(this).val()},
		dataType: "JSON",
		success: function(data) {
			// console.log(data.DATA);
			if (data.DATA.length > 0) {				
				var cus_member = [];
				$.each(data.DATA, function(idx, person) {
					cus_member.push('<option value="'+ person[0] +'">'+ person[1] +'</option>');
				});
				$('#select-purchaser').append(cus_member.join(''));
				$('#select-planner').append(cus_member.join(''));			
			};
		},
		error: function(error) {
			alert('ERROR!');
			console.log(error);
		}
	});
});

$('#sup_name').autocomplete({
	minLength: 2,
	source: function(request, response) {
		var term = request.term.trim();
		if (term in cache.supplier) {
			response(cache.supplier[term]);
			return;
		};
		$.ajax({
			url: '/index.cfm/order.companyInfo',
			data: {name_term: term, kind: 2},
			dataType: 'JSON',
			success: function(data) {
				var res = data.map(function( item ) {
					return {
						value: item.name.trim(), gid: item.gildemeisterid.trim(), id: item.companyid,
						address: item.address.trim()+' - '+item.country.trim(),
						mail: item.mail.trim(), phone: item.phone.trim(), fax: item.fax.trim()
					}; });
				// console.log(res);
				cache.customer[term] = res;
				response(res);
			}
		});
	},
	focus: function(evnt,ui) {
		$('#sup_name').val(ui.item.value);
	},
	select: function(evnt, ui) {
		$('#sup_name').attr('gid', ui.item.gid);
		$('#sup_number').val(ui.item.gid).attr('companyid',ui.item.id);
		$('#sup_address').text(ui.item.address);
		$('#sup_mail').val(ui.item.mail);
		$('#sup_phone').val(ui.item.phone);
		$('#sup_fax').val(ui.item.fax);
	}
});

$(document).on('focusout', '#sup_name', function (e) {
	$('#sup_number').trigger('change');
});

$(document).on('change', '#sup_number', function (e) {
	// console.log('changing sup name...');
	if ($(this).val() != $('#sup_name').attr('gid')) {
		$('#sup_name').val('').attr('gid','');
		$(this).val('');
		$('#sup_address').text('');
		$('#sup_person').val('');
		$('#sup_mail').val('');
		$('#sup_phone').val('');
		$('#sup_fax').val('');
		return;
	};
});

// inputting order position

$('#item_name').autocomplete({
	minLength: 2,
	source: function(request, response) {
		var term = request.term;
		if (term in cache.item) {
			response(cache.item[term]);
			return;
		};
		$.ajax({
			url: '/index.cfm/product.itemInfo',
			data: {name_term: term},
			dataType: 'JSON',
			success: function(data) {
				// console.log(data);
				var res = data.map(function( item ) {
					return {
						value: item.name.trim()+' :: '+item.pattern.trim(),
						id: item.id.trim(), pattern: item.pattern.trim() }; });
				cache.item[term] = res;
				response(res);
			}
		});
	},
	focus: function(evnt,ui) {
		$('#item_name').val(ui.item.value.split(' :: ')[0]);
		return false;
	},
	select: function(evnt, ui) {
		var info = ui.item.value.split(' :: ');
		$('#item_number').val(ui.item.id).attr('itemname', info[0]);
		$('#item_name').val(info[0]).attr('itemnumber', ui.item.id);
		$('#pattern_name').val(info[1]);
		return false;
	}
});

$('#item_number').autocomplete({
	minLength: 3,
	source: function(request, response) {
		var term = request.term;
		if (term in cache.item) {
			response(cache.item[term]);
			return;
		};
		$.ajax({
			url: '/index.cfm/product.itemInfo',
			data: {number_term: request.term},
			dataType: 'JSON',
			success: function(data) {
				// console.log(data);
				var res = data.map(function( item ) {
					return { 
						value: item.id.trim() +' :: '+ item.name.trim(),
						pattern: item.pattern.trim() 
					};
				});
				cache.item[term] = res;
				response(res);
			}
		});
	},
	focus: function(evnt,ui) {
		$('#item_number').val(ui.item.value.split(' :: ')[0]);
		return false;
	},
	select: function(evnt, ui) {
		var info = ui.item.value.split(' :: ');
		$('#item_number').val(info[0]).attr('itemname', info[1]);
		$('#item_name').val(info[1]).attr('itemnumber', info[0]);
		$('#pattern_name').val(ui.item.pattern);
		return false;
	}
});

$(document).on('focusout', '#item_number', function (e) {
	if ($(this).val() != $('#item_name').attr('itemnumber')) {
		// $(this).val('');
		$('#item_name').val('').attr('itemnumber', '');
		$('#pattern_name').text('')
	};
});

$(document).on('focusout', '#item_name', function (e) {
	if ($(this).val() != $('#item_number').attr('itemname')) {
		// $(this).val('');
		$('#item_number').val('').attr('itemname', '');
		$('#pattern_name').text('')
	};
});