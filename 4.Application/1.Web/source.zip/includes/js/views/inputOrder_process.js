var pos_list = [], ab_tmp_list = [], remain_qt = 0;

$(document).on('click', '#update_pos', function (e) {
	var newpos = { 
			number: +$('#pos_no').val(),
			item_number: $('#item_number').val(),
			item_name: $('#item_name').val(),
			pattern: $('#pattern_name').val(),
			unit_price: $('#unit_price').val().toReal(),
			quantity: $('#order_quantity').val().toReal(),
			currency: $('#select-currency').val(),
			total_price: 0
		},	msg = '';
	if (!newpos.item_number || !newpos.item_name)	
		msg += '<br>* No item is chosen';
	if (isNaN(newpos.unit_price)) 	msg += '<br>* Unit price must be greater than 0'; 
	if (newpos.quantity < 1)	msg += '<br>* Order quantity must be at least 1';
	if (ab_tmp_list.length < 1) {
		var ab = createAB('only');
		if (ab.etd == 'NaN-NaN-NaN')	msg += '<br>* Expected date must be presented';
		if (ab.confd == 'NaN-NaN-NaN')	msg += '<br>* Confirmed date must be presented';
		ab_tmp_list.push(ab);
	};
	newpos['ab_list'] = ab_tmp_list;
	// console.log(newpos);
	if (newpos.ab_list.length < 1)	msg += '<br>* No AB is available';
	if (msg) {
		$('#warning').html('Not enough position information:<br>'+msg);
		$('#modalWarn').modal('show');
		return;
	};
	for (var i = 0; i < newpos.ab_list.length; i++) {
		newpos.ab_list[i]['ab_total_price'] = newpos.unit_price * newpos.ab_list[i].ab_quantity;
		newpos.total_price += newpos.ab_list[i].ab_total_price;
		var pos_data = '<td>'+ newpos.number +'</td><td>'+newpos.ab_list[i].number+'</td>';
		pos_data += '<td>'+ newpos.item_number + '</td><td>' + newpos.pattern +'</td><td>'+ newpos.item_name +'</td>';
		pos_data += '<td>'+ newpos.quantity.insertThousandSeparator() +'</td>';
		pos_data += '<td>'+ newpos.ab_list[i].ab_quantity.insertThousandSeparator() +'</td>';
		pos_data += '<td>'+ newpos.unit_price.toMoney() +'</td>';
		pos_data += '<td>'+ newpos.ab_list[i].ab_total_price.toMoney() +'</td>';
		pos_data += '<td>'+ newpos.currency +'</td>';
		pos_data += '<td>'+ newpos.ab_list[i].transport +'</td><td>'+ newpos.ab_list[i].confd.toDateFormat(date_shown) +'</td>';
		pos_data += '<td><a class="txt-color-green posedit" href="javascript:void(0)" title="Edit">\
			<i class="ace-icon bigger-130 fa fa-pencil"></i></a>\
			<a href="javascript:void(0)"  class="txt-color-red posdel" title="Delete">\
			<i class="ace-icon bigger-130 fa fa-trash-o"></i></a></td>';

		$('#order_item').append('<tr>' + pos_data + '</tr>');
	};
	pos_list.push(newpos);
	resetPosInfo(pos_list.length + 1);
});

$(document).on('click', '#refesh_pos', function (e) { resetPosInfo(pos_list.length+1); } );

$(document).on('click','#update_ab', function (e){
	if (remain_qt < 1)	return false;
	var newab = createAB('multi'), abid_temp = pos_list.length +'-'+ ab_tmp_list.length, msg = '';
	// console.log(newab);
	if (newab.ab_quantity < 1)	msg += '<br>* Shipped quantity must be at least 1';
	if (newab.etd == 'NaN-NaN-NaN')	msg += '<br>* Expected date must be presented';
	if (newab.confd == 'NaN-NaN-NaN')	msg += '<br>* Confirmed date must be presented';
	if (msg) {
		$('#warning').html('Not enough AB information:<br>'+msg);
		$('#modalWarn').modal('show');
		return;
	};
	ab_tmp_list.push(newab);
	remain_qt -= newab.ab_quantity;
	$('<tr>').attr('id',abid_temp).appendTo('#pos_abs');
	$('<td>').text( newab.number ).appendTo('#'+abid_temp);
	$('<td>').text( newab.ab_quantity.insertThousandSeparator() ).appendTo('#'+abid_temp);
	$('<td>').text( newab.etd.toDateFormat(date_shown) ).appendTo('#'+abid_temp);
	$('<td>').text( newab.confd.toDateFormat(date_shown) ).appendTo('#'+abid_temp);
	$('<td>').text( newab.transport ).appendTo('#'+abid_temp);
	$('<td>').html('<td><a class="txt-color-green abedit" href="javascript:void(0)" title="Edit">\
		<i class="ace-icon bigger-130 fa fa-pencil"></i></a>\
		<a href="javascript:void(0)"  class="txt-color-red abdel" title="Delete">\
		<i class="ace-icon bigger-130 fa fa-trash-o"></i></a></td>').appendTo('#'+abid_temp);

	$('#multi_sq').val(remain_qt.insertThousandSeparator());
	$('#multi_rd').val('');
	$('#multi_confd').val('');
	$('#multi_trans').val('Sea').trigger('change');
});

// completing new order

$(document).on('click', '#save_order', function (e) {
	// console.log('saving new order...');
	var general = readSerializedInfo($('#order_information').serialize()), msg = "";
	// console.log(general);
	if (!general.order_no)	msg += '<br>* No order number is presented';
	if (!general.order_date)	msg += '<br>* No order date is presented';
	if (!general.customer_id)	msg += '<br>* No customer is chosen';
	if (!general.supplier_id)	msg += '<br>* No supplier is chosen';
	if (pos_list.length < 1)	msg += '<br>* No item is available';
	if (msg) {
		$('#warning').html('Not enough order information:<br>'+msg);
		$('#modalWarn').modal('show');
		return false;
	};

	$.ajax({
		type: "post",
		url: "/index.cfm/order.saveOrder",
		data: {info: JSON.stringify({order: general, position_list: pos_list})},
		dataType: "JSON",
		success: function(data) {
			// console.log(data);
			if (data.success)	data.message = 'Order has been inserted!';
			$('#warning').html(data.message);
			$('#modalWarn').modal('show');
			if (data.success) { window.location.href = "/index.cfm/order.oSearch"; };
		},
		error: function(xhr, err) {
			$('#warning').html('Connection error.<br>We\'re working on it.');
			$('#modalWarn').modal('show');
			console.log(xhr.responseText);
		}
	});
});

$(document).on('focus','#unit_price',function (e){ this.value = numberEnter(this.value); });
$(document).on('focus','#order_quantity',function (e){ this.value = numberEnter(this.value); });
$(document).on('focus','input.shipped_quantity',function (e){ this.value = numberEnter(this.value); });

$(document).on('focusout', '#unit_price', function (e) {
	var price = +($(this).val().replace(',','.'));
	$(this).val(price.toMoney());
});

$(document).on('focusout','#order_quantity',function (e){
	var qt = +$(this).val();
	remain_qt = qt;
	$(this).val(qt.insertThousandSeparator());
	$('input:text.shipped_quantity')[0].value = qt.insertThousandSeparator();
	$('input:text.shipped_quantity')[1].value = qt.insertThousandSeparator();
});

$(document).on('focusout','input:text.shipped_quantity',function (e){
	var qt = +$(this).val();
	if (qt > remain_qt) {
		$('#warning').html('The shipped quantity is too large!');
		$('#modalWarn').modal('show');
		qt = remain_qt;
	};
	$(this).val(qt.insertThousandSeparator());
});

$(document).on('click','#only_ab',function (e) {
	if ($(this).prop('checked')) {
		$('.ab').removeClass('hidden');
		$('.multi_ab').addClass('hidden');
		$('#pos_abs').empty();
		$('#only_rd').val($('#multi_rd').val());
		$('#only_confd').val($('#multi_confd').val());
	} else {
		$('.ab').addClass('hidden');
		$('.multi_ab').removeClass('hidden');
		$('#multi_sq').val($('#only_sq').val());
		$('#multi_rd').val($('#only_rd').val());
		$('#multi_confd').val($('#only_confd').val());
	};
	ab_tmp_list = [];
});

// pre-defined funcs
function numberEnter(val) {
	if (!val) return "";
	return (val.toReal() + "").replace(/[.]/g,',');
}

function createAB(type) {
	return {
		number: ab_tmp_list.length + 1,
		ab_quantity: $('#'+type+'_sq').val().toReal(),
		etd: $('#'+type+'_rd').val().toDateFormat(date_db),
		confd: $('#'+type+'_confd').val().toDateFormat(date_db),
		transport: $('#'+type+'_trans').val()
	};
}

function resetPosInfo(pos_no) {
	$('.position').find('input').each( function(idx, box) { $(box).val(''); } );
	$('#pos_no').val(pos_no);
	$('#item_number').attr('itemname','');
	$('#item_name').attr('itemnumber','');
	$('#pattern_name').text('');
	$('#select-currency').val('USD').trigger('change');
	$('.select-transport').val('Sea').trigger('change');
	$('#only_ab').prop('checked', false).trigger('click');
	ab_tmp_list = []; 
	$('#pos_abs').empty();
};

function readSerializedInfo(form_data) {
	// console.log(form_data);
	var infos = {}, arr = form_data.replace(/(\u002b)/g,' ').split('&'), tmp;
	arr.map(function(item) {
		tmp = item.split('=');
		infos[tmp[0]] = tmp[1];
	});
	infos.order_date = infos.order_date.toDateFormat(date_db);
	infos.customer_id = $('#cus_number').attr('companyid');
	infos.supplier_id = $('#sup_number').attr('companyid');
	return infos;
};


