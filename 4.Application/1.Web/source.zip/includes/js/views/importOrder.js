function parseDataFromFile(filename){
		$.ajax({
	        type: "POST",
	        url: "/index.cfm/import.parseDataFromFile/",
	        data: {
	        	filename:filename
	        	},
	        dataType: "JSON",
	        success: function (dataReturn) {
	        	// console.log(dataReturn);
	        	// window.location.href=window.location.href
	        	var scope = angular.element($('#StoreControllerID')).scope();
	        	scope.setProduct(dataReturn);
	        	scope.$apply();
	        },
		});
}

(function(){
  var app = angular.module('gemStore', ['datatables','datatables.columnfilter']);
  app.controller("StoreController",['$scope','DTOptionsBuilder','DTColumnDefBuilder',function($scope,DTOptionsBuilder, DTColumnDefBuilder){
    $scope.product = [];
    $scope.dtOptions = DTOptionsBuilder
    					.newOptions()
    					.withPaginationType('full_numbers')
    					.withColumnFilter({
    						sPlaceHolder: 'head:before',
				            aoColumns: [{
				                type: 'text'
				            }, {
				                type: 'text'
				                 
				            }, {
				                type: 'text'
				            }, {
				                type: 'text'
				            }, {
				                type: 'text'
				            }, {
				                type: 'text'
				            }, {
				                type: 'text'
				            }, {
				                type: 'text'
				            }, {
				                type: 'text'
				            }, {
				                type: 'text'
				            }, {
				                type: 'text'
				            }, {
				                type: 'text'
				            }]
        });


    $scope.dtColumnDefs = [
        DTColumnDefBuilder.newColumnDef(0),
        DTColumnDefBuilder.newColumnDef(1),
        DTColumnDefBuilder.newColumnDef(2),
        DTColumnDefBuilder.newColumnDef(3),
        DTColumnDefBuilder.newColumnDef(4),
        DTColumnDefBuilder.newColumnDef(5),
        DTColumnDefBuilder.newColumnDef(6),
        DTColumnDefBuilder.newColumnDef(7),
        DTColumnDefBuilder.newColumnDef(8),
        DTColumnDefBuilder.newColumnDef(9),
        DTColumnDefBuilder.newColumnDef(10),
        DTColumnDefBuilder.newColumnDef(11)
    ];

    $scope.theaders = ['Order No.', 'Pos.', 'AB', 'Product Item No.', 'Product Line', 'Product Item Name', "Order Q'ty", "AB Q'ty", "Accepted Q'ty", 'Remain', 'Conf. Ship. Date','Status'];

    $scope.setProduct = function(data){
    	console.log(data);
    	$scope.product = data;
    };
  }]);

})();