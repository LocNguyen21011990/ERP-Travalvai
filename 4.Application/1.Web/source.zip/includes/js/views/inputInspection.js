var today = new Date(), mtlist = [];
$('#inspection_date').val(today.toFormat(date_shown));
$('select[name=inspector2]').html($('select[name=inspector1]').html());

$(document).on('change', 'input[name=td_materials]', function (e){
	if ($(this).val() == 'yes') {
		$('#select-td_reason').val('').trigger('change')/*.addClass('hidden');
	} else {
		$('#select-td_reason').removeClass('hidden');*/
	};
});
$(document).on('change', 'input[name=ss_materials]', function (e){
	if ($(this).val() == 'yes') {
		$('#select-ss_reason').val('').trigger('change')/*.addClass('hidden');
	} else {
		$('#select-ss_reason').removeClass('hidden');*/
	};
});

$(document).on('change', 'input[name=todo_all]', function (e){
	var res = $(this).val();
	for (var i = 1; i <= $('#datatable_todos > tbody tr').length; i++) {
		$('input[name=todo'+i+']').each(function (idx, box) { 
			if ( $(box).val() == res ) {
				$(box).prop('checked', true);
				return false;
			};
		});
	};
});

$(document).on('change', '#datatable_todos > tbody input:radio', function (e) {
	var $all = $('input[name=todo_all]:checked');
	if ($all.val() != $(this).val() ) $all.prop('checked', false);
});

$(document).on('change', '#select-td_reason', function(e){
	if ($('input[name=td_materials]:checked').val() != 'no') {
		$(this).val('');
		$('#s2id_select-td_reason > a > span:first').text('Select a reason (if you choose NO)');
		return false;
	};
});
$(document).on('change', '#select-ss_reason', function(e){
	if ($('input[name=ss_materials]:checked').val() != 'no') {
		$(this).val('');
		$('#s2id_select-ss_reason > a > span:first').text('Select a reason (if you choose NO)');
		return false;
	};
});

$(document).on('click', '#update_mistake', function (e) {
	// console.log('updating...');

	var $entered_desc = $('#mistake_desc'),
		desc = $entered_desc.val().split(' :: ');
	if(desc.length < 2) return;
	var info = {
			code: $entered_desc.attr('code'),
			critical: +$('#critical_defects').val(),
			major: +$('#major_defects').val(),
			minor: +$('#minor_defects').val(),
		};
	mtlist.push(info);
	calculateTotal();

	$('<tr>').prependTo('#mistake_list');
	$( $('<td>').text( info.code ) ).appendTo('#mistake_list > tr:first');
	// $( $('<td>').text( desc[1] ) ).appendTo('#mistake_list > tr:first');
	$( $('<td>').text( desc[0] ) ).appendTo('#mistake_list > tr:first');
	$( $('<td>').addClass( 'text-center' ).text( info.critical ) ).appendTo('#mistake_list > tr:first');
	$( $('<td>').addClass( 'text-center' ).text( info.major ) ).appendTo('#mistake_list > tr:first');
	$( $('<td>').addClass( 'text-center' ).text( info.minor ) ).appendTo('#mistake_list > tr:first');
	$( $('<td>').text( $('#note').text() ) ).appendTo('#mistake_list > tr:first');

	$('#mistake_desc').val('').attr('code','');
	$('#critical_defects').val('0');
	$('#major_defects').val('0');
	$('#minor_defects').val('0');
	$('#note').text('');
});

$(document).on('click', '#complete_report', function (e){
	var ins_data = readSerializedInfo($('#inspection_report').serialize()), msg = '',
		td = $('input[name=td_materials]:checked').val(), ss = $('input[name=ss_materials]:checked').val();
	// console.log(ins_data);
	if (!ins_data.inspector1)	msg += '<br>* The first inspector must be chosen';
	if (!td)	msg += '<br>* Technical Drawing support materials are unclear';
	if (td == 'no' && ( !('td_reason' in ins_data) || ins_data.td_reason == '0') )
		msg += '<br>* There must be a reason for missing Technical Drawing materials';
	if (!ss)	msg += '<br>* Sealed Sample support materials are unclear';
	if (ss == 'no' && ( !('ss_reason' in ins_data) || ins_data.ss_reason == '0') )
		msg += '<br>* There must be a reason for missing Sealed Sample materials';
	for (var i = 1; i <= $('#datatable_todos > tbody tr').length; i++) {
		if (!$('input[name=todo'+i+']:checked').val()) {
			msg += '<br>* To do list is not completed';
			break;
		};
	};
	if (!ins_data.result)	msg += '<br>* The report must have a specific result';
	if (msg) {
		$('#warning').html('Not enough position information:<br>'+msg);
		$('#modalWarn').modal('show');
		return;
	};

	$.ajax({
		type: "post",
		url: "/index.cfm/inspection.saveInspection",
		data: {report: JSON.stringify(ins_data), mistakes: JSON.stringify(mtlist)},
		dataType: "JSON",
		success: function(data) {
			// console.log(data);
			if (data.success)	data.message = 'Report has been inserted!';
			$('#warning').html(data.message);
			$('#modalWarn').modal('show');

			if (data.success) { window.location.href = "/index.cfm/inspection.inspectionPlan"; };
		},
		error: function(xhr, err) {
			$('#warning').html('Connection error.<br>We\'re working on it.');
			$('#modalWarn').modal('show');
			console.log(xhr);
		}
	});
});

function calculateTotal() {
	var total = {critical: 0, major: 0, minor: 0};
	for (var i = 0; i < mtlist.length; i++) {
		total.critical += mtlist[i].critical;
		total.major += mtlist[i].major;
		total.minor += mtlist[i].minor;
		// console.log(total);
	};
	$('#total_defects > td:eq(3)').text(total.critical);
	$('#total_defects > td:eq(4)').text(total.major);
	$('#total_defects > td:eq(5)').text(total.minor);
};

function readSerializedInfo(form_data) {
	// console.log(form_data);
	var infos = {}, arr = form_data.replace(/(\u002b)/g,' ').split('&'), tmp;
	arr.map(function(item) {
		tmp = item.split('=');
		infos[tmp[0]] = tmp[1];
	});
	infos.ins_date = infos.ins_date.toDateFormat(date_db);
	return infos;
};
