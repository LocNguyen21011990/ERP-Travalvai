$(document).off('click','a.report').on('click', 'a.report', function(e) {
	// console.log($(this).parent().parent().attr('id'));
	// console.log($(this).parent().parent().attr('number'));
	var $chosen = $(this).parent().parent(),
		item_number = $chosen.attr('number'),
		ab = $chosen.attr('ab'),
		quantity = $chosen.find('td:eq(6)').text();
	// console.log(item_number); console.log(ab); console.log(quantity);
	$.ajax({
		type: 'get',
		url: '/index.cfm/inspection.childItems',
		data: {parentid: item_number},
		dataType: 'JSON',
		success: function(data){
			console.log(data);
			var com_link = '/index.cfm/inspection.inputInspection?schab='+ ab +'&ql='+ data.ql +'&itemno=';
			if (data.list.length < 2)	{
				window.location.href = com_link + data.list[0].id;
			} else {
				$('#item_list').empty();
				for(var i=0; i < data.list.length; i++) {
					console.log(data.list[i]);
					var id = data.list[i].itemid,
						sub_qt = ('quantity' in data.list[i]) ? data.list[i].quantity : 1,
						link = com_link + data.list[i].pattern_itemid + '&quantity=' + sub_qt;

					$('<tr>').attr('id', id).appendTo('#item_list');
					$( $('<td>').text(data.list[i].pattern_itemid) ).appendTo('#'+id);
					$( $('<td>').text(data.list[i].pattern) ).appendTo('#'+id);
					$( $('<td>').text(data.list[i].item_name) ).appendTo('#'+id);
					$( $('<td>').text(sub_qt + ' x ' + quantity) ).appendTo('#'+id);
					$( $('<td>').text('Waiting') ).appendTo('#'+id);
					$( $('<td>').text('') ).appendTo('#'+id);
					$( $('<td>').text('') ).appendTo('#'+id);
					$( $('<td>').html( $('<a>').attr('href',link).text('Report') ) ).appendTo('#'+id);
				};
				$('#modalListItem').modal('show');
			};
		},
		error: function(xhr,err){
			console.log(xhr);
		}
	});
});

var today = new Date();
$(document).on('change', '#select-filter-date', function(e) {
	console.log('filtering order '+this.value);
    $('#inputDate').hide();
	switch(this.value) {
		case 'cw': date_range = today.getCurrentWeek(); break;
		case 'cm':
			date_range = {
				start: new Date(today.getFullYear(), today.getMonth(), 1),
				end: Date.getLastMonthDate()
			};
			break;
		case 'cq': date_range = Date.getQuarterRange(today.getCurrentQuarter()); break;
		case 'nw':
			var next = new Date();
			next.setDate(today.getDate() + 7);
			date_range = next.getCurrentWeek();
			break;
		case 'nm':
			date_range = {
				start: new Date(today.getFullYear(), today.getMonth() + 1, 1),
				end: Date.getLastMonthDate(today.getMonth() + 1)
			};
			break;
		// case 'nq': date_range = Date.getQuarterRange(today.getCurrentQuarter() ); break;
		case 'dr':
    		$('#inputDate').show();
    		break;
	};
	console.log(date_range);
	$('#tFromDate').val(date_range.start.toFormat(date_shown));
	$('#tEndDate').val(date_range.end.toFormat(date_shown));
	if (this.value != 'dr') $('#inputDate').trigger('focusout');
});
