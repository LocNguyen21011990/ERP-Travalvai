(function(){
  var app = angular.module('InspectionPlanning', ['datatables']);
  app.controller("CL_Plans",['$scope','$http',function($scope,$http){
    $scope.plans = [];
     $scope.plan = '';
    $http.get("/index.cfm/inspectionplanning.getAllPlan/").success(function(dataResponse){
    	$scope.plans = JSON.parse(dataResponse);
    });
    $scope.editPlan = function(planEditItem){
      $scope.plan = planEditItem;
      if($('#faddItem').find('.fcollapsible').hasClass('selected')){
        $('#faddItem').find('.fcontent').slideToggle();
        $('#faddItem').find('.fcollapsible').toggleClass('selected')
      }
       
    };
  }]);
})();

