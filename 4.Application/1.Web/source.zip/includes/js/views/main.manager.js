$(document).ready(function() {
    Highcharts.setOptions({
        lang: {
            thousnadsSep: ','
        }
    });
    /*
     * VECTOR MAP
     */

    data_array = {
        "US" : 4977000,
        "AU" : 4873000,
        "IN" : 3671000,
        "BR" : 2476000,
        "TR" : 1476000,
        "CN" : 146000,
        "CA" : 134000,
        "BD" : 100000
    };

    $('#vector-map').vectorMap({
        map : 'world_mill_en',
        backgroundColor : '#fff',
        regionStyle : {
            initial : {
                fill : '#c4c4c4'
            },
            hover : {
                "fill-opacity" : 1
            }
        },
        series : {
            regions : [{
                values : data_array,
                scale : ['#85a8b6', '#4d7686'],
                normalizeFunction : 'polynomial'
            }]
        },
        onRegionLabelShow : function(e, el, code) {
            if ( typeof data_array[code] == 'undefined') {
                e.preventDefault();
            } else {
                var countrylbl = data_array[code];
                el.html(el.html() + ': ' + countrylbl + ' $');
            }
        }
    });
    // end vector map
 if ($("#pyramid-order-value").length) {

    $('#pyramid-order-value').highcharts({
        chart: {
            type: 'pyramid',
            marginRight: 200
        },
        title: {
            text: 'Values',
            x: -50
        },
        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b> (${point.y:,.0f})',
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black',
                    softConnector: true
                }
            }
        },
        legend: {
            enabled: false
        },
        series: [{
            name: 'Order values',
            data: [
                ['Viet Nam',      89654000],
                ['Hong Kong',            63064000],
                ['China', 45987000],
                ['India',          34976000],
                ['Others',             20846000]
            ]
        }]
    });
}

if ($("#pyramid-order-quantity").length) {

    $('#pyramid-order-quantity').highcharts({
        chart: {
            type: 'pyramid',
            marginRight: 200
        },
        title: {
            text: 'Item Quantities',
            x: -50
        },
        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b> ({point.y:,.0f} items)',
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black',
                    softConnector: true
                }
            }
        },
        legend: {
            enabled: false
        },
        series: [{
            name: 'Order quantity',
            data: [
                ['Viet Nam',      2789456800],
                ['Hong Kong',            2158956700],
                ['China', 1764289600],
                ['India',          1256489300],
                ['Others',             589649600]
            ]
        }]
    });
}

if ($("#bar-order-item").length) {
        var dataInt1 = [];
        var data1 = [];
        var data2 = [];
        var data3 = [];
        var data4 = [];
        var total1 = 0;
        var total2 = 0;
        var total3 = 0;
        for (var i = 0; i <= 4; i += 1)
            dataInt1.push(parseInt((Math.random() * 7000) + 3000));
        dataInt1.sort(function(a,b){return b - a});

        for(var i= 0; i < dataInt1.length; i +=1){
            data1.push(dataInt1[i]);
            var int2 = parseInt(Math.random() * (dataInt1[i] - 2500));
            data2.push(int2);
            var int3 = parseInt(dataInt1[i] - int2);
            data3.push(int3);
            total1 += dataInt1[i];
            total2 += int2;
            total3 += int3; 
            var int4 = parseInt(Math.random() * 200 + 50);
            data4[i] = int4;
        }
        
         $('#bar-order-item').highcharts({

            title: {
                text: 'Top 5 Product Items'
            },
            xAxis: {
                categories: ["Coffee Spoon","Bela Dinner Spoon","Bela Dinner Fork","Salad Serving Spoon","42 pcs Dinner Set"]
            },
            yAxis: {
                title: {
                    // margin: 60,
                    text: "Currency in USD"
                }
            },
            labels: {
                
            },
            series: [{
                type: 'column',
                name: 'Order values',
                data: dataInt1,
                color: Highcharts.getOptions().colors[2],
                dataLabels: {
                       enabled: true,
                    format: '${point.y:,.0f}',
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black',
                    softConnector: true
                    },
                marginLeft: 200
            },
            {
                type: 'column',
                name: 'Rejected values',
                data: data2,
                color: Highcharts.getOptions().colors[5],
                dataLabels: {
                         enabled: true,
                    format: '${point.y:,.0f}',
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black',
                    softConnector: true
                    }
            }
            
           ]
        });
    }
    // chart.yAxis[0].axisTitle.attr({
    //     text: 'new title'
    // });


    if ($("#bar-order-company").length) {
        var dataInt1 = [];
        var data1 = [];
        var data2 = [];
        var data3 = [];
        var data4 = [];
        var total1 = 0;
        var total2 = 0;
        var total3 = 0;
        for (var i = 0; i <= 4; i += 1)
            dataInt1.push(parseInt((Math.random() * 7000) + 3000));
        dataInt1.sort(function(a,b){return b - a});
        for(var i= 0; i < dataInt1.length; i +=1){
            data1.push(dataInt1[i]);
            var int2 = parseInt(Math.random() * (dataInt1[i] - 2500));
            data2.push(int2);
            var int3 = parseInt(dataInt1[i] - int2);
            data3.push(int3);
            total1 += dataInt1[i];
            total2 += int2;
            total3 += int3; 
            var int4 = parseInt(Math.random() * 200 + 50);
            data4[i] = int4;
        }
         $('#bar-order-company').highcharts({

            title: {
                text: 'Top 5 Suppliers'
            },
            xAxis: {
                categories: ["ABDOOLALLY EBRAHIM","FAIRKEEP LTD.","SAGITTARIANS","TAE YANG VINA CO., LTD.","HONG IK VINA CO. LTD."]
            },
            labels: {
                
            },
            yAxis: {
                title: {
                    // margin: 60,
                    text: "Currency in USD"
                }
            },
            series: [{
                type: 'column',
                name: 'Order values',
                data: dataInt1,
                color: Highcharts.getOptions().colors[2],
                dataLabels: {
                       enabled: true,
                    format: '${point.y:,.0f}',
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black',
                    softConnector: true
                    }
            },
            {
                type: 'column',
                name: 'Rejected values',
                data: data2,
                color: Highcharts.getOptions().colors[5],
                dataLabels: {
                         enabled: true,
                    format: '${point.y:,.0f}',
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black',
                    softConnector: true
                    }
            }
            
           ]
        });
    }

});