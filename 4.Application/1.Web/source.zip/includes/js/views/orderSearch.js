var today = new Date();

$(document).on('keypress', '#modalWarn', function (e) {
	if (e.charCode == 13)
		$('#modalWarn').modal('hide');
});

$(document).on('change', '#select-filter-date', function(e) {
	// console.log('filtering order '+this.value);
	// $('#tFromDate').attr('disabled', true);
	// $('#tEndDate').attr('disabled', true);
    // var date_range = {};
	switch(this.value) {
		case 'cw': date_range = today.getCurrentWeek(); break;
		case 'cm':
			date_range = {
				start: new Date(today.getFullYear(), today.getMonth(), 1),
				end: Date.getLastMonthDate()
			};
			break;
		case 'cq': date_range = Date.getQuarterRange(today.getCurrentQuarter()); break;
		case 'lw':
			var last = new Date();
			last.setDate(today.getDate() - 7);
			date_range = last.getCurrentWeek();
			break;
		case 'lm':
			date_range = {
				start: new Date(today.getFullYear(), today.getMonth() - 1, 1),
				end: Date.getLastMonthDate(today.getMonth() - 1)
			};
			break;
		case 'lq': date_range = Date.getQuarterRange(today.getCurrentQuarter() - 1); break;
		case 'dr':
			$('#tFromDate').attr('disabled', false);
			$('#tEndDate').attr('disabled', false);
    		break;
	};
	// console.log(date_range);
	if (this.value != 'dr') {
		$('#tFromDate').val(date_range.start.toFormat(date_shown));
		$('#tEndDate').val(date_range.end.toFormat(date_shown));
	};
});

$(document).on('click', '#filter_search', function (e) {
	// console.log('checking dates');
	var start = new Date($('#tFromDate').val()),
		end = new Date($('#tEndDate').val()),
		msg = '';
	// console.log(start+' - '+end);
	if ( isNaN( Date.parse(start) ) || isNaN( Date.parse(end) ) ) {
		msg = "Invalid format of date!";
	} else if ( start > end ) {
		msg = "The start date is greater than the end date!";
	};
	if (msg != '') {
		$('#warning').html(msg);
		$('#modalWarn').modal('show');
		return;
	};
	// console.log('start redirect');
	var filter_link = '/index.cfm/order.oSearch?fdt='+ $('#select-filter-date').val() +
		'&start='+ start.toFormat(date_db) +'&end='+ end.toFormat(date_db);
	if ($('#select-supplier').val() != '0')
		filter_link += '&supid='+ $('#select-supplier').val();
	if ($('#select-customer').val() != '0')
		filter_link += '&cusid='+ $('#select-customer').val();
	window.location.href = filter_link;
});
