$(document).ready(function() {
    if ($("#compination-rejected-quantity").length) {
    	var dataInt1 = [];
		var data1 = [];
		var data2 = [];
		var data3 = [];
		var data4 = [];
		var total1 = 0;
		var total2 = 0;
		var total3 = 0;
		for (var i = 0; i <= 11; i += 1)
			dataInt1.push(parseInt((Math.random() * 700) + 300));
		// dataInt1.sort(function(a, b){return a-b});

		for(var i= 0; i < dataInt1.length; i +=1){
			data1.push(dataInt1[i]);
			var int2 = parseInt(Math.random() * (dataInt1[i] - 250));
			data2.push(int2);
			var int3 = parseInt(dataInt1[i] - int2);
			data3.push(int3);
			total1 += dataInt1[i];
			total2 += int2;
			total3 += int3; 
			var int4 = parseInt(Math.random() * 200 + 50);
			data4[i] = int4;
		}
        $('#compination-rejected-quantity').highcharts({

	        title: {
	            text: 'Total Rejected Quantity of Items by Month'
	        },
	        xAxis: {
	            categories: [1,2,3,4,5,6,7,8,9,10,11,12]
	        },
            yAxis: {
                title: {
                    // margin: 60,
                    text: "Quantity in Piece"
                }
            },
	        labels: {
	            
	        },
	        series: [{
	            type: 'column',
	            name: 'Rejected',
	            data: data2,
	            color: Highcharts.getOptions().colors[5],
	            dataLabels: {
	                    enabled: true
	                }
	        }
	       
	        , {
	            type: 'spline',
	            name: 'Average of all companies in the same region',
	            data: data4,
	            color: Highcharts.getOptions().colors[3],
	            marker: {
	                lineWidth: 2,
	                lineColor: Highcharts.getOptions().colors[3],
	                fillColor: 'white'
	            }
	        }
	       ]
	    });
	}


    if ($("#compination-inspection-quantity").length) {
    	var dataInt1 = [];
		var data1 = [];
		var data2 = [];
		var data3 = [];
		var data4 = [];
		var total1 = 0;
		var total2 = 0;
		var total3 = 0;
		for (var i = 0; i <= 4; i += 1)
			dataInt1.push(parseInt((Math.random() * 700) + 300));
		dataInt1.sort(function(a, b){return a-b});

		for(var i= 0; i < dataInt1.length; i +=1){
			data1.push(dataInt1[i]);
			var int2 = parseInt(Math.random() * (dataInt1[i] - 250));
			data2.push(int2);
			var int3 = parseInt(dataInt1[i] - int2);
			data3.push(int3);
			total1 += dataInt1[i];
			total2 += int2;
			total3 += int3; 
			var int4 = parseInt(Math.random() * 200 + 50);
			data4[i] = int4;
		}
		console.log(Highcharts.getOptions().colors);
        $('#compination-inspection-quantity').highcharts({

            title: {
                text: 'Top 5 Product Items'
            },
            xAxis: {
                categories: ['Dinner spoon', 'Tea spoon', 'Dinner Knife', 'Pastry Fork', 'Fresh Coffee Spoon']
            },
            yAxis: {
                title: {
                    // margin: 60,
                    text: "Quantity in Piece"
                }
            },
            labels: {
                items: [{
                    html: 'Total quantities',
                    style: {
                        left: '84px',
                        top: '0px',
                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'black'
                    }
                }]
            },
            series: [{
                type: 'column',
                name: 'Rejected',
                data: data2,
                color: Highcharts.getOptions().colors[5],
                dataLabels: {
                        enabled: true
                    }
                }, {
                    type: 'column',
                    name: 'Accepted',
                    data: data1,
                    color: Highcharts.getOptions().colors[2],
                    dataLabels: {
                        enabled: true
                    }
                }
                // , 
                // {
                //     type: 'column',
                //     name: 'Inspected',
                //     data: data1,
                //     color: Highcharts.getOptions().colors[0]
                // }
                // , {
                //     type: 'spline',
                //     name: 'Average rejected quantity',
                //     data: data4,
                //     color: Highcharts.getOptions().colors[3],
                //     marker: {
                //         lineWidth: 2,
                //         lineColor: Highcharts.getOptions().colors[3],
                //         fillColor: 'white'
                //     }
                // }
                , {
                    type: 'pie',
                    name: 'Total',
                    data: [{
                            name: 'Accepted',
                            y: total1,
                            color: Highcharts.getOptions().colors[2] // Jane's color
                        }, {
                            name: 'Rejected',
                            y: total2,
                            color: Highcharts.getOptions().colors[5] // John's color
                        }
                        // , {
                        //     name: 'Inspected',
                        //     y: total1,
                        //     color: Highcharts.getOptions().colors[0] // Joe's color
                        // }
                    ],
                    center: [110, 50],
                    size: 100,
                    showInLegend: false,
                    dataLabels: {
                        enabled: false
                    }
                }]
        });
    }
	var gaugeOptions = {

        chart: {
            type: 'solidgauge'
        },

        title: null,

        pane: {
            center: ['50%', '85%'],
            size: '140%',
            startAngle: -90,
            endAngle: 90,
            background: {
                backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || '#EEE',
                innerRadius: '60%',
                outerRadius: '100%',
                shape: 'arc'
            }
        },

        tooltip: {
            enabled: false
        },

        // the value axis
        yAxis: {
            stops: [
                [0.1, Highcharts.getOptions().colors[2]], // green
                [0.49, Highcharts.getOptions().colors[2]], // green
                [0.5, Highcharts.getOptions().colors[5]], // yellow
                [0.9, Highcharts.getOptions().colors[5]] // red
            ],
            lineWidth: 0,
            minorTickInterval: null,
            tickPixelInterval: 400,
            tickWidth: 0,
            title: {
                y: -70
            },
            labels: {
                y: 16
            }
        },

        plotOptions: {
            solidgauge: {
                dataLabels: {
                    y: 5,
                    borderWidth: 0,
                    useHTML: true
                }
            }
        }
    };

    $('#shipment-status-lastmonth').highcharts(Highcharts.merge(gaugeOptions, {
        yAxis: {
            min: 0,
            max: 20
        },

        credits: {
            enabled: false
        },
        series: [{
        	name: 'Speed',
            data: [8],
            dataLabels: {
                format: '<div style="text-align:center"><span style="font-size:25px;color:' +
                    ((Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black') + '">{y}</span><br/>' +
                       '<span style="font-size:12px;color:silver">% delay</span></div>'
            },
            tooltip: {
                valueSuffix: ''
            }
        }]

    }));

        // The speed gauge
    $('#rejected-status-lastmonth').highcharts(Highcharts.merge(gaugeOptions, {
        yAxis: {
            min: 0,
            max: 20
        },

        credits: {
            enabled: false
        },
        series: [{
        	name: 'Speed',
            data: [15],
            dataLabels: {
                format: '<div style="text-align:center"><span style="font-size:25px;color:' +
                    ((Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black') + '">{y}</span><br/>' +
                       '<span style="font-size:12px;color:silver">% Reject</span></div>'
            },
            tooltip: {
                valueSuffix: ''
            }
        }]

    }));

    /*
     * FULL CALENDAR JS
     */

    if ($("#calendar").length) {
        var date = new Date();
        var d = date.getDate();
        var m = date.getMonth();
        var y = date.getFullYear();

        var calendar = $('#calendar').fullCalendar({
            lang : 'en',
            // firstDay : 1,
            editable : true,
            draggable : true,
            selectable : false,
            selectHelper : true,
            unselectAuto : false,
            disableResizing : false,

            header : {
                left : 'title', //,today
                center : 'prev, next, today',
                right : 'month, agendaWeek, agenDay' //month, agendaDay,
            },

            select : function(start, end, allDay) {
                var title = prompt('Event Title:');
                if (title) {
                    calendar.fullCalendar('renderEvent', {
                        title : title,
                        start : start,
                        end : end,
                        allDay : allDay
                    }, true // make the event "stick"
                    );
                }
                calendar.fullCalendar('unselect');
            },

            events : [{
                title : 'All Day Event',
                start : new Date(y, m, 1),
                description : 'long description',
                className : ["event", "bg-color-greenLight"],
                icon : 'fa-check'
            }, {
                title : 'Long Event',
                start : new Date(y, m, d - 5),
                end : new Date(y, m, d - 2),
                className : ["event", "bg-color-red"],
                icon : 'fa-lock'
            }, {
                id : 999,
                title : 'Repeating Event',
                start : new Date(y, m, d - 3, 16, 0),
                allDay : false,
                className : ["event", "bg-color-blue"],
                icon : 'fa-clock-o'
            }, {
                id : 999,
                title : 'Repeating Event',
                start : new Date(y, m, d + 4, 16, 0),
                allDay : false,
                className : ["event", "bg-color-blue"],
                icon : 'fa-clock-o'
            }, {
                title : 'Meeting',
                start : new Date(y, m, d, 10, 30),
                allDay : false,
                className : ["event", "bg-color-darken"]
            }, {
                title : 'Lunch',
                start : new Date(y, m, d, 12, 0),
                end : new Date(y, m, d, 14, 0),
                allDay : false,
                className : ["event", "bg-color-darken"]
            }, {
                title : 'Birthday Party',
                start : new Date(y, m, d + 1, 19, 0),
                end : new Date(y, m, d + 1, 22, 30),
                allDay : false,
                className : ["event", "bg-color-darken"]
            }, {
                title : 'Zwilling Open Day',
                start : new Date(y, m, 28),
                end : new Date(y, m, 29),
                className : ["event", "bg-color-darken"]
            }],

            eventRender : function(event, element, icon) {
                if (!event.description == "") {
                    element.find('.fc-event-title').append("<br/><span class='ultra-light'>" + event.description + "</span>");
                }
                if (!event.icon == "") {
                    element.find('.fc-event-title').append("<i class='air air-top-right fa " + event.icon + " '></i>");
                }
            }
        });

    };

    /* hide default buttons */
    $('.fc-header-right, .fc-header-center').hide();

    // calendar prev
    $('#calendar-buttons #btn-prev').click(function() {
        $('.fc-button-prev').click();
        return false;
    });

    // calendar next
    $('#calendar-buttons #btn-next').click(function() {
        $('.fc-button-next').click();
        return false;
    });

    // calendar today
    $('#calendar-buttons #btn-today').click(function() {
        $('.fc-button-today').click();
        return false;
    });

    // calendar month
    $('#mt').click(function() {
        $('#calendar').fullCalendar('changeView', 'month');
    });

    // calendar agenda week
    $('#ag').click(function() {
        $('#calendar').fullCalendar('changeView', 'agendaWeek');
    });

    // calendar agenda day
    $('#td').click(function() {
        $('#calendar').fullCalendar('changeView', 'agendaDay');
    });

    /*
     * CHAT
     */

    $.filter_input = $('#filter-chat-list');
    $.chat_users_container = $('#chat-container > .chat-list-body')
    $.chat_users = $('#chat-users')
    $.chat_list_btn = $('#chat-container > .chat-list-open-close');
    $.chat_body = $('#chat-body');

});