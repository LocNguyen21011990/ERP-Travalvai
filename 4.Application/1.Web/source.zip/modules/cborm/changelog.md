CHANGELOG
=========
## 1.1.0
* Updated cbvalidation dependency
* Prevent conditionals from being stripped from property names
* Updated build for api docs and commandbox usage for dependencies
* ORM Unique validation not working

## 1.0.2
* updates to all dependencies
* production ignore lists

## 1.0.1
* https://ortussolutions.atlassian.net/browse/CCM-15 CF11Compat - arrayContainsNoCase() Is not a function
* Lucee support

##1.0.0
* Create first module version